import theano
import theano.tensor as T
import numpy as np
import matplotlib.pyplot as plt


import pandas 
from keras.models import Sequential
from keras.layers import  Dropout
from keras.layers import LSTM, Dense
import numpy as np


from lasagne.layers import InputLayer, DenseLayer, ReshapeLayer
import lasagne.layers
import lasagne.nonlinearities
import lasagne.updates
import lasagne.objectives
import lasagne.init

from layers import NTMLayer
from memory import Memory
from controllers import DenseController
from controllers import LSTMController
from heads import WriteHead, ReadHead
from updates import graves_rmsprop

from generators import AssociativeRecallTask
from visualization import Dashboard
from visualization import learning_curve
'''
import pandas 
from keras.models import Sequential
from keras.layers import  Dropout
from keras.layers import LSTM, Dense
import numpy as np

i_path="G:/data/1N.xlsx"
i_i=pandas.ExcelFile(i_path)
df1=np.array(i_i.parse('Sheet2'))
X_train=df1[20621:20700,0:27]
Y_train=df1[20621:20700,27:29]
X_train = X_train.reshape(79,27,1)
Y_train = Y_train.reshape(79,2,1)

'''





def model(input_var, batch_size=1, size=8, num_units=100, memory_shape=(128, 20)):

    # Input Layer
    l_input = InputLayer((batch_size, None, size + 19), input_var=input_var)
    _, seqlen, _ = l_input.input_var.shape

    # Neural Turing Machine Layer
    memory = Memory(memory_shape, name='memory', memory_init=lasagne.init.Constant(1e-6), learn_init=False)
    controller = LSTMController(l_input, memory_shape=memory_shape,
        num_units=num_units, num_reads=1,
        nonlinearity=lasagne.nonlinearities.rectify,
        name='controller')
    heads = [
        WriteHead(controller, num_shifts=3, memory_shape=memory_shape, name='write', learn_init=False,
            nonlinearity_key=lasagne.nonlinearities.rectify,
            nonlinearity_add=lasagne.nonlinearities.rectify),
        ReadHead(controller, num_shifts=3, memory_shape=memory_shape, name='read', learn_init=False,
            nonlinearity_key=lasagne.nonlinearities.rectify)
    ]
    l_ntm = NTMLayer(l_input, memory=memory, controller=controller, heads=heads)

    # Output Layer
    l_output_reshape = ReshapeLayer(l_ntm, (-1, num_units))
    l_output_dense = DenseLayer(l_output_reshape, num_units=2, nonlinearity=lasagne.nonlinearities.sigmoid, \
        name='dense')
    l_output = ReshapeLayer(l_output_dense, (batch_size, seqlen, 2))

    return l_output, l_ntm


if __name__ == '__main__':
    # Define the input and expected output variable
    input_var, target_var = T.tensor3s('input', 'target')
    # The generator to sample examples from
    generator1 = AssociativeRecallTask(batch_size=1, max_iter=4000, size=8, max_num_items=6, \
        min_item_length=1, max_item_length=3)
    # The model (1-layer Neural Turing Machine)
    l_output, l_ntm = model(input_var, batch_size=generator1.batch_size,
        size=generator1.size, num_units=100, memory_shape=(128, 20))
    # The generated output variable and the loss function
    pred_var = T.clip(lasagne.layers.get_output(l_output), 1e-6, 1. - 1e-6)
    loss = T.mean(lasagne.objectives.binary_crossentropy(pred_var, target_var))
    # Create the update expressions
    params = lasagne.layers.get_all_params(l_output, trainable=True)
    learning_rate = theano.shared(1e-4)
    updates = lasagne.updates.adam(loss, params, learning_rate=learning_rate)
    # Compile the function for a training step, as well as the prediction function and
    # a utility function to get the inner details of the NTM
    train_fn = theano.function([input_var, target_var], loss, updates=updates)
    ntm_fn = theano.function([input_var], pred_var)
    ntm_layer_fn = theano.function([input_var], lasagne.layers.get_output(l_ntm, get_details=True))
    
    

    # Training
    try:
        scores, all_scores = [], []
        for i,(example_input,example_output)in generator1:
           score = train_fn(example_input,example_output)
           
           kky=(ntm_fn(example_input)).reshape(example_output.size)
           kkx=example_output.reshape(example_output.size)
           
           acc=1-np.mean(np.abs(kky-kkx)/kkx)
           print(acc)
           plt.plot(i,acc)
           scores.append(score)
           all_scores.append(score)
           if i % 10 == 0:
             mean_scores = np.mean(scores)
             if mean_scores < 0.01:
                    learning_rate.set_value(1e-5)
             print  (i, mean_scores)
        scores = []
    except KeyboardInterrupt:
        pass

    # Visualization
    def marker1(params):
        return params['num_items'] * (params['item_length'] + 1)
    def marker2(params):
        return (params['num_items'] + 1) * (params['item_length'] + 1)
    markers = [
        {
            'location': marker1,
            'style': {'color': 'red', 'ls': '-'}
        },
        {
            'location': marker2,
            'style': {'color': 'green', 'ls': '-'}
        }
    ]

    dashboard = Dashboard(generator=generator1, ntm_fn=ntm_fn, ntm_layer_fn=ntm_layer_fn, \
        memory_shape=(128, 20), markers=markers, cmap='bone')

    # Example
  #  params = generator1.sample_params()
  #  dashboard.sample(**params)
    
    params = generator1.sample_params()
    example_input1, example_output1 = generator1.sample(**params)
    x=example_input1.shape[0]
    y=example_input1.shape[1]
    z=example_input1.shape[2]
    
    xx=example_output1.shape[0]
    yy=example_output1.shape[1]
    zz=example_output1.shape[2]
    
    ex1=example_input1[0:x,0:y:1000,0:z]
    ex2=example_output1[0:xx,0:yy:1000,0:zz]
    dashboard.show(ex1, ex2, params)
    ###############################################train
    '''
    def plot_history(net_history):
    history = net_history.history
    import matplotlib.pyplot as plt
    losses = history['loss']
    val_losses = history['val_loss']
    accuracies = history['acc']
    val_accuracies = history['val_acc']
    
    plt.xlabel('max_iter')
    plt.ylabel('Loss')
    plt.plot(losses)
    plt.plot(val_losses)
    plt.legend(['loss', 'val_loss'])
    
    plt.figure()
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.plot(accuracies)
    plt.plot(val_accuracies)
    plt.legend(['acc', 'val_acc'])
    '''
    plt.figure()
    
    kky=(ntm_fn(example_input1)).reshape(example_output1.size)
    kkx=example_output1.reshape(example_output1.size)
    plt.xlabel('Number of Array (Target && Observation)-Train')
    plt.plot(kkx)
    plt.ylabel('Normalized values')
    plt.plot(kky)
    mse1=np.sum((kky-kkx)**2) 
    mse1=mse1/kkx.size
    print(mse1)
    rmse1=np.sqrt(mse1)
    print(rmse1)
    acc=1-np.mean(np.abs(kky-kkx)/kkx)
    print(acc)
    plt.legend(['Target', 'Observation'])
    
    '''
    
    plt.figure()
    plt.xlabel('max_iter')
    plt.ylabel('Accuracy')
    plt.plot(acc)
    plt.plot(mse1)
    plt.legend(['acc', 'mse'])
    
    '''
    
    
    #######test
    plt.figure()
    test1_in=df1[35000:50000,0:27]
    test1_in=test1_in.reshape(1,15000,27)
    test1_y=df1[35000:50000,27:29]
    test1_y=test1_y.reshape(1,15000,2)
    #pridect
    test1_yp=ntm_fn(test1_in)
    testx=test1_y.reshape(test1_y.size)
    testy=test1_yp.reshape(test1_yp.size)
    plt.xlabel('Number of Array (Target && Observation)-Test')
    plt.plot(testx)
    plt.ylabel('Normalized values')
    plt.plot(testy)
    msetest=(np.sum((testy-testx)**2))/testy.size
    rmsetest=np.sqrt(msetest)
    print(msetest)
    print(rmsetest)
    acc=1-np.mean(np.abs(test1_yp-test1_y)/test1_y)
    print(acc)
    plt.legend(['Target', 'Observation'])
    
    
    ######validation
    plt.figure()
    test1_in=df1[50000:56000,0:27]
    test1_in=test1_in.reshape(1,6000,27)
    test1_y=df1[50000:56000,27:29]
    test1_y=test1_y.reshape(1,6000,2)
    #pridect
    test1_yp=ntm_fn(test1_in)
    testx=test1_y.reshape(test1_y.size)
    testy=test1_yp.reshape(test1_yp.size)
    plt.xlabel('Number of Array (Target && Observation)-validation')
    plt.plot(testx)
    plt.ylabel('Normalized values')
    plt.plot(testy)
    msetest=(np.sum((testy-testx)**2))/testy.size
    rmsetest=np.sqrt(msetest)
    print(msetest)
    print(rmsetest)
    val_acc=1-np.mean(np.abs(test1_yp-test1_y)/test1_y)
    print(val_acc)
    plt.legend(['Target', 'Observation'])
    
    